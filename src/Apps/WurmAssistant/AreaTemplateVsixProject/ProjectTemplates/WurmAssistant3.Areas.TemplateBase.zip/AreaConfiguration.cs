﻿using Ninject;

namespace AldursLab.$safeprojectname$
{
    public class AreaConfiguration : IAreaConfiguration
    {
        public void Configure(IKernel kernel)
        {
        }
    }
}
